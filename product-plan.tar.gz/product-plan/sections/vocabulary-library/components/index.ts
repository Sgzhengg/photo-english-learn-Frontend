export { VocabularyList } from './VocabularyList'
export { WordDetail } from './WordDetail'
